class LinkExtractor{
    static string getAbsolutePath(string ctURL, string & path);
protected:
public:
void extract(string ctURL, string & content, list<string & links);
}
