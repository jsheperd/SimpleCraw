#ifndef HTTPSOCKET_H
#define HTTPSOCKET_H
#include <string>
#include <iostream>

class HTTPSocket {
private:
//	ClientSocket clientSocket;

public:
	std::string getURL(const std::string & url);
};



#endif /* HTTPSOCKET_H */
